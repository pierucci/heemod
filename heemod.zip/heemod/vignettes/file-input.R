library(printr)
# load the local build of the package 
library(heemod)

getwd()

source("./heemod/R/tabular_input.R")
f_read_file
specificationFile = "./models/THR/test_new_file_structure/THR_specification.csv"
f_read_file(specificationFile)

state_file = "./models/THR/test_new_file_structure/THR_states.csv"
f_read_file(state_file)

# extraction of the code below for the vignette:
baseDir <- "./models/THR/test_new_file_structure"
ref_file <- "THR_specification.csv"
base_model <- "standard"
 #the under-stated model gets fully specified:
 state_info <- heemod:::f_parse_multi_spec("./models/THR/test_new_file_structure/THR_states.csv", split_on = ".model", group_vars = "state")
 class(state_info)
 state_info
  #and values of this list are concatenated into a string by `f_create_state_definitions_from_tabular`;
 # the strings serves as an input to `define_state` command 
 # example for non-base NEW models
 states <- heemod:::f_create_state_definitions_from_tabular(state_info[[2]])
 states$state_names
 states$state_command
 states$state_def_string
 


          
          inputs <- heemod:::gather_model_info(base_dir, ref_file, base_model)
          attributes(inputs$models$standard$states$PrimaryTHR$cost)
          #encaps in gather_model_info
          {
               models <- import_models_from_files(base_dir = base_dir, ref_file = ref_file, 
                                                  base_model = base_model)
               #encaps in import_models_from_files
               {
                    ref <- f_read_file(file.path(base_dir, ref_file))
                    ref$file <- file.path(base_dir, ref$file)
                    state_info <- f_parse_multi_spec(ref[ref$data == "state", "file"], split_on = ".model", group_vars = "state")
                     #rewritten to show the under-stated model gets fully specified:
                     state_info <- f_parse_multi_spec("./models/THR/test_new_file_structure/THR_states.csv", split_on = ".model", group_vars = "state")
          
                    tm_info <- f_parse_multi_spec("./models/THR/test_new_file_structure/THR_transition_probs.csv", 
                                                  split_on = ".model", group_vars = c("from", "to"))
                    #if (any(sort(names(state_info)) != sort(names(tm_info)))) 
                    #     stop("must have state and transition matrix information for same states")
                    tm_info <- tm_info[names(state_info)]
                    models <- lapply(1:length(state_info), function(i) {
                         f_create_model_from_tabular(state_info[[i]], tm_info[[i]])
                    })
                    # f_create_model_from_tabular:
                    function(state_file,tm_file)
                    {    states <- f_create_state_definitions_from_tabular(state_file)
                         # f_create_state_definitions_from_tabular
                               function(state_info)
                              {
                              if(is.character(state_info))
                                   state_info <- f_read_file(state_info)
                              if(length(state_info) == 0 | !inherits(state_info, "data.frame"))
                                   stop("state_info must be a non-empty data frame (or the name of a file containing the frame")
                              if(!("state" %in% names(state_info)))
                                   stop('"state" should be one of the names of the input')
                              state_names <- state_info$state
                              types <- setdiff(names(state_info), c(".model", "state"))
                              discounts <- types[grep("^.discount", types)]
                              types <- setdiff(types, discounts)
                              
                              
                              ## build the "insides" of the define_state command,
                              ##   with each of the characteristics
                              state_strings <- sapply(types, function(this_col){
                                   res <- paste(this_col, state_info[, this_col], sep = "=")
                                   discount_col <- paste(".discount.", this_col, sep = "")
                                   
                                   some_discount <- discount_col %in% names(state_info)
                                   if(some_discount){
                                        discount_val <- unique(state_info[, discount_col])
                                        discount_val <- discount_val[!is.na(discount_val)]
                                        if(length(discount_val) > 1)
                                             stop(paste("more than one distinct value in", discount_col))
                                        if(length(discount_val) == 0)
                                             stop(paste("no valid discount value in", discount_col))
                                        if(discount_val < 0)
                                             stop(paste("negative discount value is invalid:", discount_col))
                                        res <- paste(this_col, "=discount(", 
                                                     state_info[, this_col],
                                                     ", ", discount_val, ")", 
                                                     sep = "")
                                   }
                                   res
                              }
                              )
                              
                              state_strings <- apply(state_strings, 1, paste, collapse = ",")
                              ## now combine those into the commands making individual states,
                              each_state_command <- 
                                   paste(state_names, "= define_state(", state_strings, ")")
                              state_defs <- paste(each_state_command, collapse = ",")
                              ##combine them to make a state list
                              state_command <- paste("define_state_list(",
                                                     state_defs, 
                                                     ")")
                              
                              list(state_def_string = state_defs, 
                                   state_command = state_command,
                                   state_names = state_names)
                              
                           }     
                    
                    
                         TM <- f_transition_prob_matrix_from_tabular(tm_file, states$state_names)
                         
                              #f_transition_prob_matrix_from_tabular
                              function(trans_probs, state_names){
                              ## if we get the name of a file instead of a data frame, 
                              ##   check for acceptable file types and read it
                              
                              if(length(trans_probs) == 0) stop("must specify trans_probs")
                              if(is.character(trans_probs))
                                   trans_probs <- f_read_file(trans_probs)
                              
                              ## error checking
                              stopifnot(all(c("from", "to", "prob") %in% names(trans_probs)))
                              
                              unique_from_states <- unique(trans_probs$from)
                              unique_states <- unique(c(trans_probs$from, trans_probs$to))
                              
                              ## we can have an initial state where people start but can't get to,
                              ##   so we don't check trans_probs$to states the way we check
                              ##   trans_probs$from states
                              stopifnot(length(state_names) > 0)
                              if(!identical(sort(unique_from_states), sort(state_names)))
                                   stop("not all specified states have a transition probability out")
                              if(!identical(sort(unique_states), sort(state_names)))
                                   stop("states specified in transition matrix are not the same as state_names")
                              
                              ## set up matrix of 0's, and then add the listed probabilities
                              num_states <- length(unique_states)
                              prob_mat <- matrix(0, nrow = num_states, ncol = num_states,
                                                 dimnames = list(state_names, state_names))
                              prob_mat[as.matrix(trans_probs[, c("to", "from")])] <- trans_probs$prob
                              
                              ## create the command to send to define_matrix
                              probs <- paste(prob_mat, collapse = ",")
                              sn <- paste('c("', 
                                          paste(state_names, collapse = "\",\""),
                                          '")', sep = "")
                              this_command <- paste("define_matrix(",
                                                    probs, 
                                                    ", state_names=",
                                                    sn,
                                                    ")")
                              list(string = this_command,
                                   tran
                         
                         model_string <- paste("define_model(", 
                                               states$state_def_string, 
                                               ", transition_matrix =", TM$string, ")")
                         eval(parse(text = model_string))
                    }
                    names(models) <- names(state_info)
                    which_base <- which(names(models) == base_model)
                    models <- models[c(which_base, setdiff(1:length(models), 
                                                           which_base))]
                    models
               }
                
               ref <- f_read_file(file.path(base_dir, ref_file))
               ref$full_file <- file.path(base_dir, ref$file)
               use_envir <- new.env()
               if ("data" %in% ref$data) {
                    load_df_from_files(base_dir, ref[ref$data == "data", 
                                                     "file"], use_envir)
               }
               if (length(ls(use_envir))) {
                    attach(use_envir, pos = 2L, name = "heemod_temp_variables_envir_detach_me")
                    on.exit(detach(name = "heemod_temp_variables_envir_detach_me"))
               }
               param_info <- f_parameters_from_tabular(ref[ref$data == "parameters", 
                                                           "full_file"], output_file_name_base = NULL, param_obj_name = "params")
               if ("survivalDataDirectory" %in% ref$data) {
                    surv_inputs <- survival_from_data(base_dir, ref[ref$data == 
                                                                         "survivalDataDirectory", "file"], data_files = ref[ref$data == 
                                                                                                                                 "surv_data_file", "file"], fit_files = as.vector(ref[ref$data == 
                                                                                                                                                                                           "fit_file", "file"]), fit_name = as.vector(ref[ref$data == 
                                                                                                                                                                                                                                               "fit_name", "file"]), fit_metric = ref[ref$data == 
                                                                                                                                                                                                                                                                                           "fit_metric", "file"], use_envir = use_envir)
               }
               output_dir <- NULL
               if ("output" %in% ref$data) 
                    output_dir <- ref[ref$data == "output", "file"]
               demographic_file <- NULL
               if ("demographics" %in% ref$data) 
                    demographic_file <- ref[ref$data == "demographics", "full_file"]
               list(models = models, param_info = param_info, use_envir = use_envir, 
                    output_dir = output_dir, demographic_file = demographic_file)
               }
     
     #follows gather_model_info
     outputs <- heemod:::execute_models(inputs, base_dir, N.prob = 50, 
                                        cost = lazyeval::lazy(cost), effect = lazyeval::lazy(qaly), 
                                        init = c(0.85, 0.15, rep(0,39)), base_model = base_model, method - "end", cycles = 35)
     
     #encapsulated in execute_models
     if (!is.null(inputs$use_envir)) {
          attach(inputs$use_envir, pos = 2L, name = "heemod_temp_variables_envir_detach_me")
          on.exit(detach(name = "heemod_temp_variables_envir_detach_me"))
     }
     if (is.null(init)) {
          message("Initial state counts not explicitely defined. Using default setting.")
          init <- c(1000L, rep(0L, get_state_number(get_states(inputs$models[[1]])) - 
                                    1))
     }
     model_runs <- run_models_(inputs$models, parameters = inputs$param_info$params, 
                               init = init, cost = cost, effect = effect, base_model = base_model, 
                               ...)


transprob = "./models/THR/test_new_file_structure/THR_transition_probs.csv"
f_read_file(transprob)
param_file = "./models/THR/test_new_file_structure/THR_parameters.xls"
pars <- heemod:::f_read_file(param_file)
dim(pars)
pars
pars[which(pars$parameter %in% c("lngamma", "gamma", "np1", "age_init", "age", "sex", "mr")), ]

demogr = "./models/THR/test_new_file_structure/THR_demographic_table.csv"
dem.tab <- f_read_file(demogr)
dem.tab[c(1:2, 30:34, 61:62), ]
mort = "./models/THR/test_new_file_structure/input_dataframes/mr_table.xlsx"
f_read_file(mort)
# demonstrate how to use the f_look_up_values_df with a short-version table

modelDir <- "./models/THR/test_new_file_structure"

THRexample <- run_models_from_files(base_dir = modelDir,ref_file = "THR_specification.csv", N.prob = 100, cost = cost, effect = qaly, base_model = "standard", save_outputs = FALSE, overwrite = TRUE, init = c(1000, rep(0, 4)), cycles = 10, method = "end")
